from scapy.all import *
import click

SELF_MAC = '02:02:02:02:02:02'    # fill in with your MAC address
BCAST_MAC = 'ff:ff:ff:ff:ff:ff'
IFACE = 'enp15s0'

def create_ARP_request_gratuituous(ipaddr_to_broadcast):
    arp = ARP(psrc=ipaddr_to_broadcast,
              hwsrc=SELF_MAC,
              pdst=ipaddr_to_broadcast)
    return Ether(dst=BCAST_MAC) / arp
    
@click.command()
def broadcast():
    sendp(create_ARP_request_gratuituous("10.0.0.156"), iface=IFACE)

if __name__ =="__main__":
    broadcast()